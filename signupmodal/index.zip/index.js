var x = document.getElementById("logIn");
var y = document.getElementById("Register");
var z = document.getElementById("sent");
var m = document.getElementById("modals");

function signup(){
    m.style.height = "700px";
    x.style.top = "700px";
    y.style.top = "300px";
}

function signin() {
    m.style.height = "630px"
    y.style.top = "650px";
    x.style.top = "300px";
}